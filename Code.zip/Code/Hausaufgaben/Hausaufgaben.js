
let body = document.body
let aktuellerNutzer = JSON.parse(localStorage.getItem("aktuellerNutzer"));
let gespeicherteFarben = localStorage.getItem(`aktuelleFarbe_${aktuellerNutzer.benutzername}`)
body.style.backgroundColor = gespeicherteFarben;



let Stundenplan = document.getElementById("Stundenplan");
let Start = document.getElementById("Start");
let Hausaufgaben = document.getElementById("Hausaufgaben");
let Profil = document.getElementById("Profil");




let newhomwork = document.getElementById("newhomwork");
newhomwork.style.backgroundColor = gespeicherteFarben;

newhomwork.addEventListener("mouseover", () =>{
    newhomwork.style.backgroundColor = "rgb(28, 29, 28)";

})
newhomwork.addEventListener("mouseleave", () =>{
    newhomwork.style.backgroundColor = gespeicherteFarben;

})





let nichtbetroffenFarbe = "rgb(83, 83, 83)";
let betroffeneFarbe = "rgba(194, 194, 194, 0.6)"
let textfarbenichtbetroffen = "white";
let textfarbenbetroffen = "black";


//Farben für die Fächer 
let deutsch =  "linear-gradient(to bottom, rgba(255, 0, 0, 0.3), rgba(152, 12, 12, 0.3))";
let mathe = "linear-gradient(to bottom, rgba(0, 68, 255, 0.3), rgba(4, 42, 148, 0.3))";
let englisch =    "linear-gradient(to bottom, rgba(187, 0, 255, 0.3), rgba(119, 0, 163, 0.3))";
let biologie =     "linear-gradient(to bottom, rgba(0, 156, 60, 0.3), rgba(0, 119, 46, 0.3))";
let spanisch =     "linear-gradient(to bottom, rgba(250, 135, 35, 0.3), rgba(232, 129, 27, 0.3))";
let chemie =     "linear-gradient(to bottom, rgba(151, 151, 151, 0.4), rgba(84, 83, 83, 0.4))";
let geographie =    "linear-gradient(to bottom, rgba(162, 65, 0, 0.3), rgba(120, 48, 0, 0.3)";
let kunst =     "linear-gradient(to bottom, rgba(255, 208, 0, 0.3), rgba(182, 143, 0, 0.3))";
let geschichte =     "linear-gradient(to bottom, rgba(226, 46, 46, 0.4), rgba(116, 116, 116, 0.4))";
let informatik =     "linear-gradient(to bottom, rgba(90, 86, 86, 0.3), rgba(50, 42, 42, 0.3))";
let WIPO =     "linear-gradient(to bottom, rgba(226, 146, 244, 0.3), rgba(219, 99, 243, 0.3))";
let bo =     "linear-gradient(to bottom, rgba(255, 192, 203, 0.3), rgba(243, 154, 169, 0.3))";
let philosophie =    "linear-gradient(to bottom, rgba(186, 186, 186, 0.3), rgba(152, 152, 152, 0.3))";

let nichterkanntesFach =   "rgba(128, 128, 233, 0.734)";









let ausgewählteSeite = document.getElementById("ausgewählteSeite")

function chagangerectStundenplan(){
    ausgewählteSeite.style.marginLeft = -90 + "px";
    ausgewählteSeite.style.width = 160 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../Stundenplan/Stundenplan.html";
    }, 390)

}

function chagangerectStart(){
    ausgewählteSeite.style.marginLeft = -206 + "px";
    ausgewählteSeite.style.width = 85 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../Startseite/index.html";
    }, 400)
}

function chagangerectProfil(){
    ausgewählteSeite.style.marginLeft = 201 + "px";
    ausgewählteSeite.style.width = 90 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../Profil/Profil.html";
    }, 410)

}














let Fachinput = document.getElementById("Fachhinzufügen")

Fachinput.addEventListener("input", function(){
    let Rect = document.getElementById("rectaround");

    if (Fachinput.value === "Deutsch" || Fachinput.value === "De" || Fachinput.value === "DE"){
        console.log("Deusch erkannt!!")
        Rect.style.background = deutsch;
        Fachinput.value = "Deutsch"
    }
    else if (Fachinput.value === "Mathe" || Fachinput.value === "Ma"){
        Rect.style.background = mathe;
        Fachinput.value = "Mathe"
    }
    else if (Fachinput.value === "Biologie" || Fachinput.value === "Bio"){
        Rect.style.background = biologie;
        Fachinput.value = "Biologie"
    }
    else if (Fachinput.value === "Spanisch" || Fachinput.value === "Sp" || Fachinput.value === "Espanol" || Fachinput.value === "Español" || Fachinput.value === "Es"){
        Rect.style.background = spanisch;
        Fachinput.value = "Español"

    }
    else if (Fachinput.value === "Englisch" || Fachinput.value === "En"){
        Rect.style.background = englisch
        Fachinput.value = "Englisch"

    }
    else if (Fachinput.value === "Chemie" || Fachinput.value === "Ch"){
        Rect.style.background = chemie;
        Fachinput.value = "Chemie"

    }
    else if (Fachinput.value === "Geographie" || Fachinput.value === "Erdkunde" || Fachinput.value === "Er" || Fachinput.value === "Geo"){
        Rect.style.background = geographie;
        Fachinput.value = "Geographie"

    }
    else if (Fachinput.value === "Kunst" || Fachinput.value ==="Ku"){
        Rect.style.background = kunst;
        Fachinput.value = "Kunst"

    }
    else if (Fachinput.value === "Geschichte" || Fachinput.value ==="Ge"){
        Rect.style.background = geschichte;
        Fachinput.value = "Geschichte"

    }
    else if (Fachinput.value === "WIPO" || Fachinput.value === "Wirtschaft und Politik" ){
        Rect.style.background = WIPO;
        Fachinput.value = "Wirtschaft und Politik"

    }
    else if (Fachinput.value === "Bo" || Fachinput.value === "Berufsorientierung"
    ){
        Rect.style.background = bo;
        Fachinput.value = "Berufsorientierung"

    }
    else if (Fachinput.value === "Philosophie" || Fachinput.value === "Ph"){
        Rect.style.background = philosophie;
        Fachinput.value = "Philosophie";
    }

})


function neueHausaufgabe() {    
    
     
    // Existierende Elemente abrufen
    const Rect = document.getElementById("Rect");


    // NEUE Elemente erstellen
    const Rect2 = Rect.cloneNode(true);
    Rect2.classList.add("Hausaufgabenliste");

    let neueID
     neueID += 1;
    Rect2.id = "Rect" + neueID;

    document.body.appendChild(Rect2)
    Fachhinzufügen2.addEventListener("input", function(){
        let Farbe = " ";
        if (Fachhinzufügen2.value === "Deutsch" || Fachhinzufügen2.value === "De" || Fachhinzufügen2.value === "DE"){
            console.log("Deusch erkannt!!")
            Farbe = deutsch;
            Fachhinzufügen2.value = "Deutsch"
        }
        else if (Fachhinzufügen2.value === "Mathe" || Fachhinzufügen2.value === "Ma"){
            Farbe = mathe;
            Fachhinzufügen2.value = "Mathe"
        }
        else if (Fachhinzufügen2.value === "Biologie" || Fachhinzufügen2.value === "Bio"){
            Farbe = biologie;
            Fachhinzufügen2.value = "Biologie"
        }
        else if (Fachhinzufügen2.value === "Spanisch" || Fachhinzufügen2.value === "Sp" || Fachhinzufügen2.value === "Espanol" || Fachhinzufügen2.value === "Español" || Fachhinzufügen2.value === "Es"){
            Farbe = spanisch;
            Fachhinzufügen2.value = "Español"

        }
        else if (Fachhinzufügen2.value === "Englisch" || Fachhinzufügen2.value === "En"){
            Farbe = englisch
            Fachhinzufügen2.value = "Englisch"

        }
        else if (Fachhinzufügen2.value === "Chemie" || Fachhinzufügen2.value === "Ch"){
            Farbe = chemie;
            Fachhinzufügen2.value = "Chemie"

        }
        else if (Fachinput.value === "Geographie" || Fachhinzufügen2.value === "Erdkunde" || Fachhinzufügen2.value === "Er" || Fachhinzufügen2.value === "Geo"){
            Farbe = geographie;
            Fachhinzufügen2.value = "Geographie"

        }
        else if (Fachhinzufügen2.value === "Kunst" || Fachhinzufügen2.value ==="Ku"){
            Farbe = kunst;
            Fachhinzufügen2.value = "Kunst"

        }
        else if (Fachhinzufügen2.value === "Geschichte" || Fachhinzufügen2.value ==="Ge"){
            Farbe = geschichte;
            Fachhinzufügen2.value = "Geschichte"

        }
        else if (Fachhinzufügen2.value === "WIPO" || Fachhinzufügen2.value === "Wirtschaft und Politik" ){
            Farbe = WIPO;
            FachiFachhinzufügen2nput.value = "Wirtschaft und Politik"

        }
        else if (Fachhinzufügen2.value === "Bo" || Fachhinzufügen2.value === "Berufsorientierung"
        ){
            Farbe = bo;
            Fachhinzufügen2.value = "Berufsorientierung"

        }
        else if (Fachhinzufügen2.value === "Philosophie" || Fachhinzufügen2.value === "Ph"){
            Farbe = philosophie
            Fachhinzufügen2.value = "Philosophie";
        }
        Rect2.style.background = Farbe;
        Fachhinzufügen2.style.color = Farbe
        Hausaufgabenhinzufügen2.style.color = Farbe

})
}
