

let body = document.body
let aktuellerNutzer = JSON.parse(localStorage.getItem("aktuellerNutzer"));
let gespeicherteFarben = localStorage.getItem(`aktuelleFarbe_${aktuellerNutzer.benutzername}`)
body.style.backgroundColor = gespeicherteFarben;


let ausgewählteSeite = document.getElementById("ausgewählteSeite")


function chagangerectStundenplan(){
    ausgewählteSeite.style.marginLeft = -90 + "px";
    ausgewählteSeite.style.width = 160 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../../Stundenplan/Stundenplan.html";
    }, 390)

}

function chagangerectHausaufgaben(){
    ausgewählteSeite.style.marginLeft = 74 + "px";
    ausgewählteSeite.style.width = 180 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../../Hausaufgaben/Hausaufgaben.html";
    }, 400)
}

function chagangerectStart(){
    ausgewählteSeite.style.marginLeft = -203 + "px";
    ausgewählteSeite.style.width = 85 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../../Startseite/index.html";
    }, 410)
}

function chagangerectProfil(){
    window.location.href = "../Profil.html"
}








function Fächerhinzufügen(){
    let NeueFächer = document.getElementById("NeueFächer");
    let Einezeile = document.getElementById("Einezeile");
    let Rect = document.getElementById("Rect");
    let eingabeValue = document.getElementById("Eingabe").value;
    let eingabe = document.getElementById("Eingabe");
    let inputfarben = document.getElementById("inputfarben");
    let showColor = document.getElementById("showColor");



    // Vorher gespeicherte Fächer laden oder leeres Array nehmen
    let fächer = JSON.parse(localStorage.getItem(`Fächer_${aktuellerNutzer.benutzername}`)) || [];
    let Fächer_Farben = JSON.parse(localStorage.getItem(`Fächer_Farben_${aktuellerNutzer.benutzername}`)) || [];

    console.log(fächer)
    fächer.push(eingabeValue);
    Fächer_Farben.push(inputfarben.value)
    console.log("das sind die Farben fächer", 
        Fächer_Farben
    )


    // Zurück in localStorage speichernd
    localStorage.setItem(`Fächer_${aktuellerNutzer.benutzername}`, JSON.stringify(fächer));
    localStorage.setItem(`Fächer_Farben_${aktuellerNutzer.benutzername}`, JSON.stringify(Fächer_Farben));



    let neueFächer = document.createElement("input");
    let neueFarben = document.createElement("input");
    let Farbkasten = document.createElement("div");
    let Einezeile2 = document.createElement("div");
    Einezeile2.appendChild(neueFächer);
    Einezeile2.appendChild(neueFarben);
    Einezeile2.appendChild(Farbkasten);
    neueFächer.classList.add("Eingabe");
    neueFarben.classList.add("neueFarben");
    Farbkasten.classList.add("Farbkasten");
    Einezeile2.classList.add("Einezeile");

    neueFächer.value = eingabeValue;
    neueFarben.value = inputfarben.value;
    Farbkasten.style.backgroundColor = inputfarben.value;




    showColor.style.backgroundColor = "transparent";
    inputfarben.value = ""

    //neueFarben.placeholder = "Farbe:";  // ✅

    Rect.appendChild(Einezeile2);
    eingabe.focus();
    eingabe.value = ""; 
    
    


}





let inputfarben = document.getElementById("inputfarben");
let showColor = document.getElementById("showColor");

inputfarben.addEventListener("focusout", function(){
    
    
    showColor.style.backgroundColor =  inputfarben.value

})

inputfarben.addEventListener("input", function(){
    if (inputfarben.value === "rg"){
        inputfarben.value = "rgb()";
        inputfarben.setSelectionRange(4, 4); // Cursor nach "rgb("
    }
})

showColor.addEventListener("click", function(){
    inputfarben.focus();
})




/*document.body.addEventListener("keydown", (event) => {
    let Eingabe = document.getElementById("Eingabe")
    
    if ( document.activeElement.classList.contains("Eingabe") || document.activeElement === Eingabe || document.activeElement.classList.contains("neueFarben")){
        
        if (Eingabe.value.trim()  || classList.contains("Eingabe").value.trim() !== " "){
                if (event.key == "Enter"){

                
                    
                    Fächerhinzufügen()
                }
            }
    }
})*/




let Rect = document.getElementById("Rect");

document.addEventListener("DOMContentLoaded", function(){

let Fächer = JSON.parse(localStorage.getItem(`Fächer_${aktuellerNutzer.benutzername}`)) || [];
let Fächer_Farben = JSON.parse(localStorage.getItem(`Fächer_Farben_${aktuellerNutzer.benutzername}`)) || [];
console.log("Geladene Fächer:", Fächer);
console.log("Geladene Farben:", Fächer_Farben);

    
    if (Fächer.length !== Fächer_Farben.length) {
    console.warn("Fächer und Farben stimmen nicht überein!");
    // Optional: beides neu setzen oder nur Fächer anzeigen
    }

    for (let i= 0 ; i<Fächer.length; i++){
        console.log("ist geladen", Fächer.length);
        let neueFächer = document.createElement("input");
        let neueFarben = document.createElement("input");
        let Farbkasten = document.createElement("div");
        let Einezeile2 = document.createElement("div");


        Einezeile2.appendChild(neueFächer);
        Einezeile2.appendChild(neueFarben);
        Einezeile2.appendChild(Farbkasten);
        neueFächer.classList.add("Eingabe");
        neueFarben.classList.add("neueFarben");
        Farbkasten.classList.add("Farbkasten");
        Einezeile2.classList.add("Einezeile");

        
        //neueFarben.placeholder = "Farbe:";
        neueFarben.value = Fächer_Farben[i];
        neueFächer.value = Fächer[i];
        Farbkasten.style.backgroundColor = Fächer_Farben[i]
        console.log("Fächer Faben" ,Fächer_Farben);
        Rect.appendChild(Einezeile2);




    }
}); 




function trash(){
    localStorage.removeItem(`Fächer_${aktuellerNutzer.benutzername}`);
    localStorage.removeItem(`Fächer_Farben_${aktuellerNutzer.benutzername}`);

    location.reload()

}







