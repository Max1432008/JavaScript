let ausgewählteSeite = document.getElementById("ausgewählteSeite")
let body = document.getElementById("body")

let vergrößen = 0;
let aktuelleGröße = window.getComputedStyle(document.body).fontSize; // z. B. "16px"
aktuelleGröße = parseFloat(aktuelleGröße)

body.style.fontSize = (aktuelleGröße + vergrößen) + "px";


function chagangerectStundenplan(){
    ausgewählteSeite.style.marginLeft = -90 + "px";
    ausgewählteSeite.style.width = 160 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../../Stundenplan/Stundenplan.html";
    }, 390)

}

function chagangerectHausaufgaben(){
    ausgewählteSeite.style.marginLeft = 74 + "px";
    ausgewählteSeite.style.width = 180 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../../Hausaufgaben/Hausaufgaben.html";
    }, 400)
}

function chagangerectStart(){
    ausgewählteSeite.style.marginLeft = -203 + "px";
    ausgewählteSeite.style.width = 85 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../../Startseite/index.html";
    }, 410)
}

function chagangerectProfil(){
    window.location.href = "../Profil.html"
}


let BenutzerName = document.getElementById("BennutzerName");
let BenutzerPasswort = document.getElementById("BenutzerPasswort");
let aktuellerNutzer = JSON.parse(localStorage.getItem("aktuellerNutzer"));


BenutzerName.innerText = aktuellerNutzer.benutzername;
BenutzerPasswort.innerText = aktuellerNutzer.benutzerpasswort;






function Einstellungenspeichern() {
    let erste = document.getElementById("ersteCheckbox");
    let zweite = document.getElementById("zweiteCheckbox");
    let Standard = document.getElementById("Standard");
    let vierte = document.getElementById("vierteCheckbox")

    let FarbName = "";
    let FarbWert = "";

    if (erste.checked) {
        FarbName = "Dunkel blau";
        FarbWert = "rgb(18, 45, 70)";
    } else if (zweite.checked) {
        FarbName = "Dunkel grün";
        FarbWert = "rgb(34, 41, 35)";
    } else if (Standard.checked) {
        FarbName = "Standard";
        FarbWert = "rgb(40, 38, 38)";
    } else if (vierte.checked) {
        FarbName = "Dunkel rot";
        FarbWert = "rgb(46, 32, 32)";
    }

    localStorage.setItem(`aktuelleFarbe_${aktuellerNutzer.benutzername}`, FarbWert);
    localStorage.setItem(`FarbName_${aktuellerNutzer.benutzername}`, FarbName);
    window.location.reload();



}
let ändern = document.getElementById("ändern");
function größer(){

    let alleElemente = ändern.querySelectorAll("*");
    
    alleElemente.forEach(element => {
        let aktuelleGröße = window.getComputedStyle(element).fontSize;
        aktuelleGröße = parseFloat(aktuelleGröße)
        element.style.fontSize = (aktuelleGröße + 1) + "px";
    });
    aktuelleSchriftgrößeAnzeige.innerText =  (aktuelleGröße + 1) + " Schriftgröße";


}

function kleiner(){
    let alleElemente = ändern.querySelectorAll("*");
    
    alleElemente.forEach(element => {
        let aktuelleGröße = window.getComputedStyle(element).fontSize;
        aktuelleGröße = parseFloat(aktuelleGröße)
        localStorage.setItem("aktuelle Schriftgröße", aktuelleGröße)
        let Schriftgrößeaktuell = localStorage.getItem("aktuelle Schriftgröße")

        element.style.fontSize = (Schriftgrößeaktuell - 1) + "px";
    });
    aktuelleSchriftgrößeAnzeige.innerText =  (aktuelleGröße - 1) + " Schriftgröße";

}


window.onload = function(){
    let gespeicherteFarben = localStorage.getItem(`aktuelleFarbe_${aktuellerNutzer.benutzername}`)
    let gespeicherteFarbenNamen = localStorage.getItem(`FarbName_${aktuellerNutzer.benutzername}`)
    let erste = document.getElementById("ersteCheckbox");
    let zweite = document.getElementById("zweiteCheckbox");
    let Standard = document.getElementById("Standard");
    let vierte = document.getElementById("vierteCheckbox")


    document.body.style.backgroundColor = gespeicherteFarben;
    if (gespeicherteFarbenNamen === "Dunkel blau"){
        erste.checked = true
    } else if (gespeicherteFarbenNamen === "Dunkel grün"){
        zweite.checked = true
    } else if (gespeicherteFarbenNamen === "Standard"){
        Standard.checked = true
    } else if (gespeicherteFarbenNamen === "Dunkel rot"){
        vierte.checked = true
    }
    else{
        Standard.checked = true
    }



    


}

