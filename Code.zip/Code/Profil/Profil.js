
let ausgewählteSeite = document.getElementById("ausgewählteSeite")

let body = document.body
let aktuellerNutzer = JSON.parse(localStorage.getItem("aktuellerNutzer"));
let gespeicherteFarben = localStorage.getItem(`aktuelleFarbe_${aktuellerNutzer.benutzername}`)
body.style.backgroundColor = gespeicherteFarben;

let Benutzer = document.getElementById("Benutzer")

Benutzer.innerText = aktuellerNutzer.benutzername



function chagangerectStundenplan(){
    ausgewählteSeite.style.marginLeft = -90 + "px";
    ausgewählteSeite.style.width = 160 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../Stundenplan/Stundenplan.html";
    }, 390)

}

function chagangerectHausaufgaben(){
    ausgewählteSeite.style.marginLeft = 74 + "px";
    ausgewählteSeite.style.width = 180 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../Hausaufgaben/Hausaufgaben.html";
    }, 400)
}

function chagangerectStart(){
    ausgewählteSeite.style.marginLeft = -203 + "px";
    ausgewählteSeite.style.width = 85 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../Startseite/index.html";
    }, 410)
}





