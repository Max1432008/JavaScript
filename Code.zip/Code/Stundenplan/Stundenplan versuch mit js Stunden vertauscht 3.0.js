
let body = document.body
let aktuellerNutzer = JSON.parse(localStorage.getItem("aktuellerNutzer"));
let gespeicherteFarben = localStorage.getItem(`aktuelleFarbe_${aktuellerNutzer.benutzername}`)
let gespeicherteFächer = JSON.parse(localStorage.getItem(`Fächerhinzufügen_${aktuellerNutzer.benutzername}`)) || [];
let sidebar_draußen = localStorage.getItem(`Sidbar_draußen${aktuellerNutzer.benutzername}`)
let Fächer_Farben = JSON.parse(localStorage.getItem(`Fächer_Farben_${aktuellerNutzer.benutzername}`)) || [];


console.log("gespeicherteFächer: ", gespeicherteFächer)
body.style.backgroundColor = gespeicherteFarben;





let ausgewählteSeite = document.getElementById("ausgewählteSeite")

function chagangerectHausaufgaben(){
    ausgewählteSeite.style.marginLeft = 74 + "px";
    ausgewählteSeite.style.width = 180 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../Hausaufgaben/Hausaufgaben.html";
    }, 400)
}

function chagangerectStart(){

    ausgewählteSeite.style.marginLeft = -203 + "px";
    ausgewählteSeite.style.width = 85 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";


    setTimeout(() => {
        window.location.href = "../Startseite/index.html";
    }, 400)
}

function chagangerectProfil(){
    ausgewählteSeite.style.marginLeft = 201 + "px";
    ausgewählteSeite.style.width = 90 + "px";
    ausgewählteSeite.style.transition = 0.5 + "s";
    setTimeout(() => {
        window.location.href = "../Profil/Profil.html";
    }, 410)

}







function Zeit(){

    let EndederTabelle = 465;
    let StartTabelle = 60;
    let starzeit = 8* 60;
    let endzeit = 15 * 60;
    let Zeitanzeige = document.getElementById("Zeitanzeige");
    let Zeitpunkt = document.getElementById("Zeitpunkt");
    
    let jetzt = new Date().toLocaleTimeString();
    aktuelleminuten = new Date().getMinutes();
    aktuellesekunden = new Date().getSeconds();
    aktuelleStunden = new Date().getHours();
    //console.log(jetzt); // Gibt die aktuelle Uhrzeit aus

    Zeitanzeige.innerText = String(aktuelleStunden)  +  " : " +  String(aktuelleminuten);

    let y2 = (StartTabelle + aktuelleminuten)
    //console.log(y2)
    if (y2 >= EndederTabelle){
        y2 = EndederTabelle
    }

    
    Zeitpunkt.style.top = 84 + ((300 / (14.5 - 7.3)) ) + "px";
    setInterval(() => {
        Zeitpunkt.style.top += 1 + "px";
        // Hier kommt dein Code hin – z. B. neue Hausaufgabe erzeugen, Uhrzeit anzeigen, etc.
    }, 60000); // 60000 Millisekunden = 1 Minute
  
    
}

setInterval(Zeit, 10);






// ––––––––––––––––––––––           Ab hier beginnt der Code mit den Hausaufgaben               –––––––––––––––––––––






let Fächerhinzufügen1 = document.getElementById("Fächerhinzufügen1");
const sidebar = document.getElementById("sidebar");
const table = document.getElementById("table");
let Fächerbearbeiten = document.getElementById("Fächerbearbeiten");

let aktuellesFach
let clickedButton
let SeitenLeistedraußen = false;

let Fächer = JSON.parse(localStorage.getItem(`Fächer_${aktuellerNutzer.benutzername}`));
let Fächerbearbeiten_button = document.getElementById("Fächerbearbeiten");



if (sidebar_draußen === "draußen") {
    sidebar.classList.remove("hidden");
    
    
    SeitenLeistedraußen = false;
    Fächerbearbeiten.innerText = "Bearbeiten";
    Fächerbearbeiten_button.classList.remove("Fächerbearbeiten-keinerBildschrirm");
    table.style.marginLeft = "0px";



} else {
    sidebar.classList.add("hidden");
    table.style.marginLeft = "220px";
    SeitenLeistedraußen = true;
    Fächerbearbeiten.innerText = "Fertig";
    Fächerbearbeiten_button.classList.add("Fächerbearbeiten-keinerBildschrirm");


}








document.getElementById("Fächerbearbeiten").addEventListener("click", () => {

    // Sichtbarkeit umschalten
    sidebar.classList.toggle("hidden");

    sidebar.style.transition = "margin-left 0.5s ease";

    // Zustand prüfen und reagieren
    if (!sidebar.classList.contains("hidden")){
 

        localStorage.setItem(`Sidbar_draußen${aktuellerNutzer.benutzername}`, "draußen");




        table.style.marginLeft = "0px";
        Fächerbearbeiten.innerText = "Bearbeiten";
        let farbeändern =  table.querySelectorAll("td");
        farbeändern.forEach(td => {
            td.style.backgroundColor = "transparent";
            td.style.border = "1px solid black";
        })
        SeitenLeistedraußen = false;


        Fächerbearbeiten_button.classList.remove("Fächerbearbeiten-keinerBildschrirm");


    } else {

        localStorage.setItem(`Sidbar_draußen${aktuellerNutzer.benutzername}`, "nicht draußen");

        table.style.marginLeft = "220px";
        Fächerbearbeiten.innerText = "Fertig";
        SeitenLeistedraußen = true;


            setTimeout(() => {
            Fächerbearbeiten_button.classList.add("Fächerbearbeiten-keinerBildschrirm");
        }, 150);




    }


});





    
const anzahl_an_Stunden = 5;
const anzahl_an_Pausen = 4;
let Liste = [];
let aktiv = 1;


let ListeFächerMitId = [];  // Array von Objekten


function Tabelleerstellen(){

for (let i= 0; i<anzahl_an_Stunden +1 + anzahl_an_Pausen ;i++){
    
    let buttonFächer= document.getElementById("buttonFächer");
    let Tabelle = document.getElementById("table");


    let Spalte = document.createElement("tr");
    Tabelle.appendChild(Spalte);    

    for (let j=0; j<6 ; j++){
        let Zeile = document.createElement("td");
        Spalte.appendChild(Zeile);
        let button_der_Stunden = document.createElement("button");

        if (j == 0){
            button_der_Stunden = document.createElement("div");  
            button_der_Stunden.classList = "ersteZeile";
            button_der_Stunden.textContent = `Stunde ${i + 1}`;
            Zeile.appendChild(button_der_Stunden);


        } else{
            Zeile.appendChild(button_der_Stunden);
            let FachFürButton = gespeicherteFächer.find(e => e.id === button_der_Stunden.id);
            if (FachFürButton){
                button_der_Stunden.textContent = FachFürButton.fach;
            }
            button_der_Stunden.classList.add("buttonFächer");
            button_der_Stunden.id = (`iist${i}jist${j}`)
            


            
            

            

            button_der_Stunden.addEventListener("click", (event) => {
                if (!SeitenLeistedraußen){
                } else {



                    clickedButton = event.target;
                    if (!Liste.includes(clickedButton)) {
                        Liste.push(clickedButton);
                    }    
                    
                    
                    
                if (aktiv == 1){
                    
                    Zeile.style.border = "2px solid red";
                    Zeile.style.backgroundColor = "rgba(223, 96, 96, 0.22)";


                    
                    aktiv = 2;
                }
                else {
                    Zeile.style.border = "1px solid black";
                    Zeile.style.backgroundColor = "transparent";
                    Liste = Liste.filter(btn => btn !== clickedButton);  // btn wurde hier jetzt benannt als Variable  
                    // –––––––––––     Sorgt dafür, dass überprüft wird ob die Buttons in der Liste noch geclickt sind –––––––

                    aktiv = 1;
                    
                }

            }
            })
            
        }
    }


}


}
Tabelleerstellen()



for (let k= 0 ; k<Fächer.length; k++){

    let button = document.createElement("button"); // Neuen Button erstellen
    button.innerText = Fächer[k];                  // Beschriftung = Fachname
    button.classList.add("Fächerhinzufügen");           // Optional: Klasse für Styling
    
    listeFächer.appendChild(button);
    console.log(Fächer.length)


    button.addEventListener("click", () => {
        console.log("Geklickt:", Fächer[k]);
        // z. B. Unterricht laden, anzeigen, filtern ...


        if (Liste.length > 0){

            Texteinsetzen(k)

        }
        else{
            window.alert("Geht nicht")
        }

    });

}


function Texteinsetzen(k) {


    Liste.forEach(clickedButton => {
        let IdVonButton = clickedButton.id;
        let vorhandenesFach = gespeicherteFächer.find(e => e.id === IdVonButton);

        if (vorhandenesFach) {
            vorhandenesFach.fach = Fächer[k]; // aktualisieren
            
        } else {
            gespeicherteFächer.push({ id: IdVonButton, fach: Fächer[k] }); // neu hinzufügen
        }


        // Zeige das Fach im Button
        clickedButton.textContent = Fächer[k];
        
        
        let zeile = clickedButton.parentElement;
        zeile.style.border = "1px solid black";
        //zeile.style.backgroundColor = Fächer_Farben[k];
        aktiv = 1;

        

        
    });

    // ❗ Jetzt korrekt das ganze Array speichern
    localStorage.setItem(`Fächerhinzufügen_${aktuellerNutzer.benutzername}`, JSON.stringify(gespeicherteFächer));

    console.log( gespeicherteFächer);



    }



